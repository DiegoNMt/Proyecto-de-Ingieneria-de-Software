import java.io.*;
import java.util.*;

public class Actividad8 {

    static String MATRICULA = "A3063467"; 
    
    // Tamaño óptimo (Número primo grande para evitar colisiones)
    static final int HASH_SIZE = 99991; 

    
    static class HashEntry {
        String token;
        Map<String, Integer> docFrequencies; 
        
        public HashEntry() {
            this.token = "";
            this.docFrequencies = new LinkedHashMap<>();
        }
    }

    public static void main(String[] args) {
        if (args.length < 2) {
            System.out.println("Uso: java Actividad8 <carpeta_tokenizada> <carpeta_salida>");
            return;
        }

        File inputDir = new File(args[0]);
        File outputDir = new File(args[1]);

        if (!inputDir.exists()) {
            System.out.println("Error: No existe la carpeta de entrada.");
            return;
        }
        outputDir.mkdirs();

       
        HashEntry[] hashTable = new HashEntry[HASH_SIZE];
        for (int i = 0; i < HASH_SIZE; i++) {
            hashTable[i] = new HashEntry(); 
        }

        int colisiones = 0;
        int tokensUsados = 0;

        try {
            System.out.println("--- INICIANDO ACTIVIDAD 8 (Hash Table) ---");
            BufferedWriter log = new BufferedWriter(new FileWriter("a8_" + MATRICULA + ".txt"));
            long inicioTotal = System.nanoTime();

            // --- 1. LLENAR LA HASH TABLE ---
            File[] archivos = inputDir.listFiles((dir, name) -> name.endsWith(".txt"));
            if (archivos != null) {
                for (File archivo : archivos) {
                    long inicioArchivo = System.nanoTime();
                    String docName = archivo.getName().replace(".txt", ".html");

                    try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
                        String token;
                        while ((token = br.readLine()) != null) {
                            token = token.trim();
                            if (!token.isEmpty()) {
                                
                                
                                long sum = 0;
                                for (int i = 0; i < token.length(); i++) {
                                    sum = (sum * 19) + token.charAt(i);
                                }
                                int index = (int) (Math.abs(sum) % HASH_SIZE);

                                
                                while (!hashTable[index].token.equals("") && !hashTable[index].token.equals(token)) {
                                    index = (index + 1) % HASH_SIZE;
                                    colisiones++;
                                }

                              
                                if (hashTable[index].token.equals("")) {
                                    hashTable[index].token = token;
                                    tokensUsados++;
                                }
                                
                                
                                Map<String, Integer> docs = hashTable[index].docFrequencies;
                                docs.put(docName, docs.getOrDefault(docName, 0) + 1);
                            }
                        }
                    }

                    double tArchivo = (System.nanoTime() - inicioArchivo) / 1.0E9D;
                    log.write(archivo.getAbsolutePath() + " procesado en: " + String.format(Locale.US, "%.4f", tArchivo) + " s\n");
                }
            }

            // --- 2. EXPORTAR DICCIONARIO Y POSTING (ASCII) ---
            long inicioEscritura = System.nanoTime();
            File archDiccionario = new File(outputDir, "diccionario.txt");
            File archPosting = new File(outputDir, "posting.txt");

            try (BufferedWriter bwDic = new BufferedWriter(new FileWriter(archDiccionario));
                 BufferedWriter bwPost = new BufferedWriter(new FileWriter(archPosting))) {
                
                int postingPointer = 0; 

                
                for (int i = 0; i < HASH_SIZE; i++) {
                    HashEntry entry = hashTable[i];

                    if (entry.token.equals("")) {
                        
                        bwDic.write((i + 1) + "\t0\t0\t-1");
                        bwDic.newLine();
                    } else {
                        
                        int df = entry.docFrequencies.size();
                        bwDic.write((i + 1) + "\t" + entry.token + "\t" + df + "\t" + postingPointer);
                        bwDic.newLine();

                        
                        for (Map.Entry<String, Integer> docEntry : entry.docFrequencies.entrySet()) {
                            bwPost.write((postingPointer + 1) + " " + docEntry.getKey() + ";" + docEntry.getValue());
                            bwPost.newLine();
                            postingPointer++;
                        }
                    }
                }
            }
            double tEscritura = (System.nanoTime() - inicioEscritura) / 1.0E9D;
            double tTotal = (System.nanoTime() - inicioTotal) / 1.0E9D;

            // Reporte final en Log
            log.write("\n-----------------------------------\n");
            log.write("Tamano Hash Table:  " + HASH_SIZE + "\n");
            log.write("Tokens unicos:      " + tokensUsados + "\n");
            log.write("Colisiones totales: " + colisiones + "\n");
            log.write("Tiempo escritura:   " + String.format(Locale.US, "%.4f", tEscritura) + " s\n");
            log.write("Tiempo total:       " + String.format(Locale.US, "%.4f", tTotal) + " s\n");
            log.close();

            System.out.println("Proceso Hash completado. Colisiones detectadas: " + colisiones);
            System.out.println("Resultados en: " + outputDir.getAbsolutePath());

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}