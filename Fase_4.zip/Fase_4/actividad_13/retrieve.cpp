#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <map>
#include <algorithm>
#include <chrono>


using namespace std;

string toLowerCase(string str) {
    transform(str.begin(), str.end(), str.begin(), ::tolower);
    return str;
}

struct Resultado {
    int docID;
    double score;
};

int main(int argc, char* argv[]) {
    if (argc < 2) {
        cout << "Uso: retrieve <palabras>\n";
        return 1;
    }

    auto start = chrono::high_resolution_clock::now();

    vector<string> queries;
    for (int i = 1; i < argc; i++) {
        queries.push_back(toLowerCase(argv[i]));
    }


    ifstream dicFile("output_final_Actividad_11/diccionario.txt");
    ifstream postFile("output_final_Actividad_11/posting.txt");
    ifstream docFile("output_final_Actividad_11/documentos.txt");

    if (!dicFile || !postFile || !docFile) {
        cout << "Error al abrir archivos.\n";
        return 1;
    }



    map<int, string> docMap;
    string line;
    while (getline(docFile, line)) {
        stringstream ss(line);
        int id;
        string name;
        ss >> id >> name;
        docMap[id] = name;
    }
    map<int, double> scores;

    for (string query : queries) {

        dicFile.clear();
        dicFile.seekg(0);

        int pointer = -1;
        int df = 0;

        while (getline(dicFile, line)) {
            stringstream ss(line);
            int id;
            string token;
            int p;

            ss >> id >> token >> df >> p;

            if (token == query) {
                pointer = p;
                break;
            }
        }


        if (pointer == -1) continue;

        postFile.clear();
        postFile.seekg(0);

        int current = 0;
        int leidos = 0;

        while (getline(postFile, line)) {
            if (current >= pointer && leidos < df) {
                stringstream ss(line);
                int pos, docID;
                double peso;
                ss >> pos >> docID >> peso;

                scores[docID] += peso;
                leidos++;
            }
            current++;
        }
    }
    vector<Resultado> resultados;
    for (auto& par : scores) {
        resultados.push_back({par.first, par.second});

    }

    sort(resultados.begin(), resultados.end(), [](Resultado a, Resultado b) {
        return a.score > b.score;
    });

    cout << "Top documents:\n";
    int limite = min(10, (int)resultados.size());

    for (int i = 0; i < limite; i++) {
        cout << i + 1 << ". " << docMap[resultados[i].docID] << "\n";
    }


    auto end = chrono::high_resolution_clock::now();
    chrono::duration<double> elapsed = end - start;

    ofstream log("a13_A3069241.txt", ios::app);
    log << "Consulta: ";
    for (string q : queries) log << q << " ";
    log << "| Tiempo: " << elapsed.count() << " s\n";
    log.close();

    cout << "\nTiempo: " << elapsed.count() << " segundos\n";



    return 0;
}